package Exceptions;

public class IncorrectKeyException extends Exception {
   public IncorrectKeyException() {
      System.out.println("Given Key is Incorrect!");
   }
}
